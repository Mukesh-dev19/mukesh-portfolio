import { lazy, Suspense } from "react";
import { Nav } from "@/components/portfolio/Nav";
import { Hero } from "@/components/portfolio/Hero";
import { ScrollProgress } from "@/components/portfolio/ScrollProgress";
import { Loader } from "@/components/portfolio/Loader";

const About = lazy(() => import("@/components/portfolio/About").then((m) => ({ default: m.About })));
const Education = lazy(() => import("@/components/portfolio/Education").then((m) => ({ default: m.Education })));
const Skills = lazy(() => import("@/components/portfolio/Skills").then((m) => ({ default: m.Skills })));
const Projects = lazy(() => import("@/components/portfolio/Projects").then((m) => ({ default: m.Projects })));
const Achievements = lazy(() => import("@/components/portfolio/Achievements").then((m) => ({ default: m.Achievements })));
const Gate = lazy(() => import("@/components/portfolio/Gate").then((m) => ({ default: m.Gate })));
const Vision = lazy(() => import("@/components/portfolio/Vision").then((m) => ({ default: m.Vision })));
const Contact = lazy(() => import("@/components/portfolio/Contact").then((m) => ({ default: m.Contact })));
const Footer = lazy(() => import("@/components/portfolio/Footer").then((m) => ({ default: m.Footer })));
const MouseGlow = lazy(() => import("@/components/portfolio/MouseGlow").then((m) => ({ default: m.MouseGlow })));

export default function App() {
  return (
    <main className="relative overflow-x-hidden">
      <Loader />
      <ScrollProgress />
      <Suspense fallback={null}>
        <MouseGlow />
      </Suspense>
      <Nav />
      <Hero />
      <Suspense fallback={<div className="h-32" />}>
        <About />
        <Education />
        <Skills />
        <Projects />
        <Achievements />
        <Gate />
        <Vision />
        <Contact />
        <Footer />
      </Suspense>
    </main>
  );
}
