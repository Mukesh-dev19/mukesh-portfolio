import { motion } from "framer-motion";
import { ArrowRight, Download, Mail, MapPin, Linkedin } from "lucide-react";
import { GridBackground } from "./GridBackground";

// Place your resume as public/Mukesh_B_Resume.pdf in the repo
const resumeAsset = { url: "/Mukesh_B_Resume.pdf" };

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
      <GridBackground />
      <div className="absolute inset-0 bg-[var(--gradient-hero)]" />

      <div className="relative z-10 mx-auto max-w-5xl px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs font-mono text-muted-foreground mb-8"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-electric opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-electric" />
          </span>
          <MapPin className="h-3 w-3" /> Chennai, India · Available for Internships
        </motion.div>

        <motion.h1
          initial="hidden"
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.07, delayChildren: 0.15 } },
          }}
          className="text-5xl sm:text-7xl md:text-8xl font-bold text-gradient leading-[0.95]"
        >
          {"Mukesh B".split("").map((ch, i) => (
            <motion.span
              key={i}
              variants={{
                hidden: { opacity: 0, y: 40, rotateX: -90 },
                visible: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.55, ease: [0.2, 0.8, 0.2, 1] } },
              }}
              className="inline-block"
              style={{ transformOrigin: "50% 100%" }}
            >
              {ch === " " ? "\u00A0" : ch}
            </motion.span>
          ))}
        </motion.h1>


        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-6 text-lg sm:text-xl font-display text-foreground/90"
        >
          Electrical & Electronics Engineering Student
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.35 }}
          className="mt-4 mx-auto max-w-2xl text-base sm:text-lg text-muted-foreground"
        >
          Building the future through <span className="text-electric">Power Systems</span>,{" "}
          <span className="text-electric">IoT</span>, Smart Energy & <span className="text-electric">Electric Vehicle</span> technologies.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <a
            href="#projects"
            className="group inline-flex items-center gap-2 rounded-xl bg-electric px-6 py-3 font-medium text-primary-foreground shadow-[var(--shadow-electric)] hover:shadow-[var(--shadow-glow)] transition-all hover:-translate-y-0.5"
          >
            View Projects <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </a>
          <a
            href={resumeAsset.url}
            download="Mukesh_B_Resume.pdf"
            className="inline-flex items-center gap-2 rounded-xl glass-strong px-6 py-3 font-medium hover:bg-white/10 transition"
          >
            <Download className="h-4 w-4" /> Download Resume
          </a>
          <a
            href="https://www.linkedin.com/in/mukeshbalaji19/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn Profile"
            className="group connect-linkedin inline-flex items-center gap-2 rounded-xl px-6 py-3 font-medium text-muted-foreground hover:text-foreground transition hover:scale-105"
          >
            <Linkedin className="h-4 w-4" /> LinkedIn
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 rounded-xl px-6 py-3 font-medium text-muted-foreground hover:text-foreground transition"
          >
            <Mail className="h-4 w-4" /> Contact Me
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.7 }}
          className="mt-20 grid grid-cols-3 gap-4 max-w-2xl mx-auto"
        >
          {[
            { v: "2029", l: "GATE EE Target" },
            { v: "2+", l: "Live Projects" },
            { v: "8+", l: "Tech Domains" },
          ].map((s) => (
            <div key={s.l} className="glass rounded-xl p-4">
              <div className="text-2xl sm:text-3xl font-display font-bold text-electric">{s.v}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.l}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
