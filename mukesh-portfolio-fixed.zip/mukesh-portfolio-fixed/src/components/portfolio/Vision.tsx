import { motion } from "framer-motion";
import { Section } from "./Section";

const roadmap = [
  { year: "2026", title: "Build EEE Expertise", desc: "Deepen fundamentals: circuits, machines, signals." },
  { year: "2027", title: "Internship & IoT Builds", desc: "First industry internship; ship real IoT systems." },
  { year: "2028", title: "EV & Power Research", desc: "Hands-on with EV powertrains and grid integration." },
  { year: "2029", title: "Crack GATE EE", desc: "Top-tier GATE rank → M.Tech / R&D pathway." },
  { year: "2030+", title: "Sustainable Energy Ventures", desc: "Build companies at the intersection of energy + software." },
];

export function Vision() {
  return (
    <Section id="vision" eyebrow="Future Vision" title="The 2026–2030 Roadmap">
      <div className="relative">
        <div className="absolute top-6 left-0 right-0 h-px bg-gradient-to-r from-transparent via-electric/40 to-transparent hidden md:block" />
        <div className="grid md:grid-cols-5 gap-5">
          {roadmap.map((r, i) => (
            <motion.div
              key={r.year}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative"
            >
              <div className="hidden md:flex absolute left-1/2 -top-0 -translate-x-1/2 -translate-y-1/2 h-3 w-3 rounded-full bg-electric shadow-[0_0_15px_var(--electric)]" />
              <div className="glass-strong rounded-2xl p-5 mt-6">
                <div className="font-display font-bold text-2xl text-electric">{r.year}</div>
                <h4 className="font-semibold mt-2">{r.title}</h4>
                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{r.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
