import { motion } from "framer-motion";
import { GraduationCap } from "lucide-react";
import { Section } from "./Section";

const items = [
  {
    year: "2025 – 2029",
    title: "B.E. Electrical & Electronics Engineering",
    org: "Meenakshi College of Engineering · Anna University",
    desc: "Core curriculum in circuits, machines, power systems and electronics. Active in hackathons and student projects.",
    active: true,
  },
  {
    year: "2029 →",
    title: "GATE EE + Industry / M.Tech",
    org: "Target: Top-rank GATE EE · Power Systems specialization",
    desc: "Planned trajectory into advanced power systems research or industry R&D in EV / Energy.",
  },
];

export function Education() {
  return (
    <Section id="education" eyebrow="Education" title="Academic Timeline">
      <div className="relative max-w-3xl mx-auto">
        <div className="absolute left-[19px] md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-electric via-electric/30 to-transparent md:-translate-x-px" />
        {items.map((it, i) => (
          <motion.div
            key={it.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className={`relative flex md:items-center mb-10 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
          >
            <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-background border-2 border-electric animate-pulse-glow">
              <GraduationCap className="h-4 w-4 text-electric" />
            </div>
            <div className="ml-14 md:ml-0 md:w-1/2 md:px-8">
              <div className="glass-strong rounded-2xl p-5 electric-border">
                <div className="font-mono text-xs text-electric mb-2">{it.year}</div>
                <h3 className="font-display font-semibold text-lg">{it.title}</h3>
                <div className="text-sm text-muted-foreground mt-1">{it.org}</div>
                <p className="text-sm text-muted-foreground mt-3">{it.desc}</p>
                {it.active && (
                  <span className="inline-block mt-3 rounded-full bg-electric/10 text-electric text-xs px-2 py-0.5 font-mono">
                    ● ACTIVE
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
