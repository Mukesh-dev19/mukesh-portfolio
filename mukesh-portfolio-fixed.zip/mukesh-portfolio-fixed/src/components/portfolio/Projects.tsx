import { motion } from "framer-motion";
import { ArrowUpRight, Github, Zap } from "lucide-react";
import { Section } from "./Section";

const projects = [
  {
    name: "OneSwap",
    tag: "EdTech · Prototype",
    description:
      "A student resource sharing platform built to improve academic collaboration. Designed for low-friction sharing of notes, materials and study tools across colleges.",
    tools: ["Replit", "Lovable", "Emergent", "GitHub"],
    accent: "from-electric/30 to-transparent",
  },
  {
    name: "IoT Home Energy Monitor",
    tag: "Hardware · IoT",
    description:
      "An affordable IoT-driven system that tracks real-time household energy usage, identifies waste and helps homes adopt efficient consumption habits.",
    tools: ["Microcontroller", "Sensors", "Cloud Dashboard", "Python"],
    accent: "from-cyan-400/30 to-transparent",
  },
];

export function Projects() {
  return (
    <Section id="projects" eyebrow="Selected Work" title="Projects" subtitle="Engineering experiments at the intersection of hardware, software and sustainability.">
      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((p, i) => (
          <motion.article
            key={p.name}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            whileHover={{ y: -6 }}
            className="group relative glass-strong rounded-3xl p-8 overflow-hidden electric-border"
          >
            <div className={`absolute -top-24 -right-24 h-64 w-64 rounded-full bg-gradient-to-br ${p.accent} blur-3xl opacity-50 group-hover:opacity-80 transition`} />
            <div className="relative">
              <div className="flex items-start justify-between mb-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-electric/10">
                  <Zap className="h-5 w-5 text-electric" />
                </div>
                <span className="font-mono text-xs text-muted-foreground">{p.tag}</span>
              </div>
              <h3 className="text-2xl font-display font-bold mb-2 flex items-center gap-2">
                {p.name}
                <ArrowUpRight className="h-5 w-5 text-electric opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition" />
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">{p.description}</p>
              <div className="flex flex-wrap gap-2">
                {p.tools.map((t) => (
                  <span key={t} className="rounded-full glass px-3 py-1 text-xs font-mono text-muted-foreground">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </motion.article>
        ))}
      </div>
      <div className="mt-10 text-center">
        <a
          href="https://github.com/Mukesh-dev19"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-electric transition"
        >
          <Github className="h-4 w-4" /> More on GitHub
        </a>
      </div>
    </Section>
  );
}
