import { Github, Linkedin, Mail, Zap } from "lucide-react";

const socials = [
  {
    icon: Linkedin,
    label: "LinkedIn",
    href: "https://www.linkedin.com/in/mukeshbalaji19/",
    accent: "linkedin",
  },
  {
    icon: Github,
    label: "GitHub",
    href: "https://github.com/Mukesh-dev19",
    accent: "github",
  },
  {
    icon: Mail,
    label: "Email",
    href: "mailto:mukeshmukeshbalaji2008@gmail.com",
    accent: "email",
  },
];

export function Footer() {
  return (
    <footer className="relative border-t border-white/5 mt-10">
      <div className="mx-auto max-w-6xl px-6 py-12 text-center">
        <Zap className="h-6 w-6 text-electric mx-auto mb-4" />
        <blockquote className="text-lg sm:text-xl font-display italic text-foreground/90 max-w-2xl mx-auto">
          "Engineering is not only about solving problems; it is about creating possibilities."
        </blockquote>
        <div className="mt-6 flex items-center justify-center gap-3">
          {socials.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target={s.href.startsWith("mailto:") ? undefined : "_blank"}
              rel={s.href.startsWith("mailto:") ? undefined : "noopener noreferrer"}
              aria-label={s.label}
              className={`connect-${s.accent} inline-flex h-10 w-10 items-center justify-center rounded-xl glass hover:scale-110 transition-transform duration-200`}
            >
              <s.icon className="h-4 w-4" />
            </a>
          ))}
        </div>
        <div className="mt-8 text-xs text-muted-foreground font-mono">
          © {new Date().getFullYear()} MUKESH B · CHENNAI, INDIA · BUILT WITH ⚡
        </div>
      </div>
    </footer>
  );
}
