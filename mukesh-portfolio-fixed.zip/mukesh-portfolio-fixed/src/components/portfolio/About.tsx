import { motion } from "framer-motion";
import { Section } from "./Section";
import { Battery, Cpu, Leaf, Lightbulb, Radio, Zap } from "lucide-react";

const interests = [
  { icon: Zap, label: "Power Systems" },
  { icon: Battery, label: "Electric Vehicles" },
  { icon: Leaf, label: "Renewable Energy" },
  { icon: Radio, label: "IoT & Sensors" },
  { icon: Cpu, label: "Embedded Systems" },
  { icon: Lightbulb, label: "Automation" },
];

export function About() {
  return (
    <Section id="about" eyebrow="About" title="Engineering the next decade of energy">
      <div className="grid md:grid-cols-5 gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="md:col-span-3 space-y-5 text-muted-foreground leading-relaxed text-[15px]"
        >
          <p>
            I'm <span className="text-foreground font-medium">Mukesh B</span>, an Electrical &
            Electronics Engineering undergraduate at{" "}
            <span className="text-foreground">Meenakshi College of Engineering</span>, affiliated to
            Anna University. I'm fascinated by the systems that move electrons — from{" "}
            <span className="text-electric">power grids</span> to{" "}
            <span className="text-electric">electric vehicles</span> to{" "}
            <span className="text-electric">smart sensors</span>.
          </p>
          <p>
            My focus is on building real-world expertise in power systems, renewable energy,
            embedded IoT and EV technologies, while preparing rigorously for{" "}
            <span className="text-foreground">GATE EE 2029</span>. I treat engineering as a craft:
            curious, hands-on, and obsessed with efficiency.
          </p>
          <p>
            Long-term, I want to build energy technology companies that make sustainable power
            accessible — combining hardware, software, and good design the way Tesla and SpaceX do.
          </p>
        </motion.div>

        <div className="md:col-span-2 grid grid-cols-2 gap-3">
          {interests.map((it, i) => (
            <motion.div
              key={it.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="glass electric-border rounded-xl p-4 flex flex-col gap-2 hover:bg-white/[0.06] transition"
            >
              <it.icon className="h-5 w-5 text-electric" />
              <span className="text-sm font-medium">{it.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
