import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useEffect, useState } from "react";
import { AnimatedLogo } from "./AnimatedLogo";

const links = [
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#gate", label: "GATE" },
  { href: "#vision", label: "Vision" },
  { href: "#contact", label: "Contact" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string>("");
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 30));

  useEffect(() => {
    const ids = links.map((l) => l.href.slice(1));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(`#${e.target.id}`);
        });
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-4 left-1/2 z-50 -translate-x-1/2 w-[min(95%,1100px)]"
    >
      <motion.nav
        animate={{
          backgroundColor: scrolled ? "oklch(0.14 0.02 250 / 0.75)" : "oklch(0.18 0.025 250 / 0.4)",
          backdropFilter: scrolled ? "blur(28px) saturate(180%)" : "blur(16px) saturate(140%)",
          borderColor: scrolled ? "oklch(0.72 0.19 240 / 0.25)" : "oklch(1 0 0 / 0.08)",
        }}
        transition={{ duration: 0.3 }}
        className="flex items-center justify-between rounded-2xl px-5 py-3 border"
      >
        <a href="#" className="flex items-center gap-2 font-display font-bold">
          <AnimatedLogo />
          <span>Mukesh B</span>
        </a>
        <ul className="hidden md:flex items-center gap-1 text-sm text-muted-foreground">
          {links.map((l) => {
            const isActive = active === l.href;
            return (
              <li key={l.href} className="relative">
                <a
                  href={l.href}
                  className={`relative px-3 py-1.5 rounded-lg transition ${
                    isActive ? "text-foreground" : "hover:text-foreground hover:bg-white/5"
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute inset-0 rounded-lg bg-electric/15 border border-electric/30"
                      transition={{ type: "spring", stiffness: 300, damping: 28 }}
                    />
                  )}
                  <span className="relative">{l.label}</span>
                </a>
              </li>
            );
          })}
        </ul>
        <a
          href="#contact"
          className="hidden sm:inline-flex items-center gap-1.5 rounded-lg bg-electric px-4 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition hover:-translate-y-0.5"
        >
          Hire Me
        </a>
      </motion.nav>
    </motion.header>
  );
}
