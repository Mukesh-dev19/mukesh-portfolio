import { motion } from "framer-motion";

/**
 * Innovative engineering mark: a stylized "M" formed from circuit traces,
 * with an orbiting electron node and a pulsing core. Replaces the generic
 * lightning bolt for a more engineering-forward identity.
 */
export function AnimatedLogo({ size = 22 }: { size?: number }) {
  return (
    <motion.svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      initial={{ rotate: -8, opacity: 0 }}
      animate={{ rotate: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="drop-shadow-[0_0_8px_var(--electric)]"
    >
      {/* Outer hex frame */}
      <motion.polygon
        points="16,2 28,9 28,23 16,30 4,23 4,9"
        stroke="var(--electric)"
        strokeWidth="1.2"
        strokeOpacity="0.55"
        fill="none"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.2, ease: "easeInOut" }}
      />
      {/* Circuit "M" trace */}
      <motion.path
        d="M7 22 L7 11 L16 18 L25 11 L25 22"
        stroke="var(--electric)"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.1, delay: 0.2, ease: "easeOut" }}
      />
      {/* Solder pads */}
      <circle cx="7" cy="22" r="1.4" fill="var(--electric)" />
      <circle cx="25" cy="22" r="1.4" fill="var(--electric)" />
      {/* Pulsing core */}
      <motion.circle
        cx="16"
        cy="18"
        r="2"
        fill="var(--electric)"
        animate={{ scale: [1, 1.4, 1], opacity: [0.85, 1, 0.85] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        style={{ transformOrigin: "16px 18px" }}
      />
      {/* Orbiting electron */}
      <motion.g
        animate={{ rotate: 360 }}
        transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
        style={{ transformOrigin: "16px 16px" }}
      >
        <circle cx="16" cy="6" r="1.1" fill="white" />
      </motion.g>
    </motion.svg>
  );
}
