import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { AnimatedLogo } from "./AnimatedLogo";

export function Loader() {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setShow(false), 1500);
    return () => clearTimeout(t);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-background"
        >
          <div className="relative">
            <motion.div
              className="absolute inset-0 -m-8 rounded-full"
              style={{ boxShadow: "0 0 60px 10px var(--electric)" }}
              animate={{ opacity: [0.2, 0.8, 0.2], scale: [0.9, 1.1, 0.9] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            />
            <div className="relative">
              <AnimatedLogo size={72} />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
