import { motion } from "framer-motion";
import { Github, Linkedin, Mail, ArrowUpRight } from "lucide-react";
import { Section } from "./Section";

const LINKEDIN_URL = "https://www.linkedin.com/in/mukeshbalaji19/";
const GITHUB_URL = "https://github.com/Mukesh-dev19";
const EMAIL = "mukeshmukeshbalaji2008@gmail.com";

const links = [
  {
    icon: Linkedin,
    label: "LinkedIn Profile",
    sub: "Connect, message & follow",
    href: LINKEDIN_URL,
    accent: "linkedin",
    external: true,
  },
  {
    icon: Github,
    label: "GitHub Profile",
    sub: "Mukesh-dev19",
    href: GITHUB_URL,
    accent: "github",
    external: true,
  },
  {
    icon: Mail,
    label: "Email Me",
    sub: EMAIL,
    href: `mailto:${EMAIL}`,
    accent: "email",
    external: false,
  },
] as const;

export function Contact() {
  return (
    <Section
      id="contact"
      eyebrow="Connect"
      title="Connect With Me"
      subtitle="Open to internships, collaborations, and conversations about energy, EVs, and IoT."
    >
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
        {links.map((c, i) => {
          const fallback = !c.href;
          return (
            <motion.a
              key={c.label}
              href={fallback ? undefined : c.href}
              target={c.external ? "_blank" : undefined}
              rel={c.external ? "noopener noreferrer" : undefined}
              aria-label={c.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.45, delay: i * 0.08 }}
              whileHover={{ scale: 1.03, y: -4 }}
              whileTap={{ scale: 0.98 }}
              className={`group connect-card connect-${c.accent} glass-strong rounded-2xl p-6 flex items-center gap-4 relative overflow-hidden`}
            >
              <div className="connect-icon flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-white/5 border border-white/10 transition">
                <c.icon className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-display font-semibold text-base">
                  {fallback ? "Link unavailable" : c.label}
                </div>
                <div className="text-xs text-muted-foreground truncate mt-0.5">
                  {fallback ? "Please check back soon" : c.sub}
                </div>
              </div>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition opacity-60 group-hover:opacity-100" />
            </motion.a>
          );
        })}
      </div>
    </Section>
  );
}
