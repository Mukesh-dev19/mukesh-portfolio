import { motion, useMotionValue, useSpring } from "framer-motion";
import { useEffect } from "react";

export function MouseGlow() {
  const x = useMotionValue(-200);
  const y = useMotionValue(-200);
  const sx = useSpring(x, { stiffness: 120, damping: 20, mass: 0.3 });
  const sy = useSpring(y, { stiffness: 120, damping: 20, mass: 0.3 });

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const onMove = (e: MouseEvent) => {
      x.set(e.clientX - 300);
      y.set(e.clientY - 300);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [x, y]);

  return (
    <motion.div
      aria-hidden
      style={{ x: sx, y: sy }}
      className="pointer-events-none fixed top-0 left-0 z-[5] h-[600px] w-[600px] rounded-full opacity-[0.18] mix-blend-screen"
    >
      <div className="h-full w-full rounded-full bg-[radial-gradient(circle,var(--electric)_0%,transparent_60%)]" />
    </motion.div>
  );
}
