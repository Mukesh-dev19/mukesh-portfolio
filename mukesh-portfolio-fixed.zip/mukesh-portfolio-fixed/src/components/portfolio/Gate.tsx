import { motion } from "framer-motion";
import { Section } from "./Section";
import { Target, BookOpen, BrainCircuit, Trophy } from "lucide-react";

const phases = [
  { icon: BookOpen, year: "Y1–Y2", title: "Foundations", desc: "Math, Circuits, Networks, Signals" },
  { icon: BrainCircuit, year: "Y3", title: "Core Mastery", desc: "Machines, Power Systems, Control, Electronics" },
  { icon: Target, year: "Y4", title: "Intensive Prep", desc: "PYQs, mock tests, weak-area drilling" },
  { icon: Trophy, year: "2029", title: "GATE EE Attempt", desc: "Target: top percentile rank" },
];

export function Gate() {
  return (
    <Section id="gate" eyebrow="Long Game" title="My GATE EE 2029 Mission" subtitle="A multi-year commitment to mastering Electrical Engineering fundamentals at depth.">
      <div className="glass-strong rounded-3xl p-8 sm:p-10 electric-border">
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-xs text-muted-foreground">PREPARATION PROGRESS</span>
          <span className="font-mono text-xs text-electric">PHASE 1 / 4</span>
        </div>
        <div className="h-2 rounded-full bg-white/5 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: "18%" }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-electric to-electric-glow shadow-[0_0_20px_var(--electric)]"
          />
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {phases.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className={`rounded-2xl p-5 border ${i === 0 ? "bg-electric/10 border-electric/40" : "bg-white/[0.02] border-white/5"}`}
            >
              <p.icon className={`h-5 w-5 mb-3 ${i === 0 ? "text-electric" : "text-muted-foreground"}`} />
              <div className="font-mono text-[10px] text-electric mb-1">{p.year}</div>
              <h4 className="font-semibold text-sm">{p.title}</h4>
              <p className="text-xs text-muted-foreground mt-1">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
