import { motion } from "framer-motion";
import { Award, Hammer, Lightbulb, Trophy } from "lucide-react";
import { Section } from "./Section";

const items = [
  { icon: Lightbulb, title: "Creative Thinker Award", sub: "Recognized for innovative problem-solving" },
  { icon: Trophy, title: "Stravex'26 Hackathon", sub: "Participant — collaborative ideation sprint" },
  { icon: Hammer, title: "Engineering Workshops", sub: "Hands-on training in core EEE domains" },
  { icon: Award, title: "Innovation Activities", sub: "Active in student-led engineering initiatives" },
];

export function Achievements() {
  return (
    <Section id="achievements" eyebrow="Recognition" title="Certifications & Achievements">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {items.map((it, i) => (
          <motion.div
            key={it.title}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="glass rounded-2xl p-5 hover:bg-white/[0.06] transition group"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-electric/10 mb-4 group-hover:scale-110 transition">
              <it.icon className="h-5 w-5 text-electric" />
            </div>
            <h3 className="font-semibold text-sm">{it.title}</h3>
            <p className="text-xs text-muted-foreground mt-1">{it.sub}</p>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
