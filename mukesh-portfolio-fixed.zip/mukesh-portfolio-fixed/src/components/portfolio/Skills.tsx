import { motion } from "framer-motion";
import { Section } from "./Section";
import { Cpu, Code2, Wrench, Zap } from "lucide-react";

const groups = [
  {
    icon: Zap,
    title: "Core Electrical",
    skills: ["Circuit Analysis", "Electrical Machines", "Power Systems", "Renewable Energy", "Electrical Measurements"],
  },
  {
    icon: Cpu,
    title: "IoT & Embedded",
    skills: ["Sensors", "Microcontrollers", "Smart Monitoring", "Automation"],
  },
  {
    icon: Code2,
    title: "Programming",
    skills: ["Python", "Git / GitHub", "AI-Assisted Development"],
  },
  {
    icon: Wrench,
    title: "Tools",
    skills: ["Replit", "Lovable", "Emergent", "Excel", "PowerPoint", "Word"],
  },
];

export function Skills() {
  return (
    <Section id="skills" eyebrow="Capabilities" title="Technical Stack" subtitle="The toolkit I'm sharpening for the next generation of energy and IoT systems.">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {groups.map((g, i) => (
          <motion.div
            key={g.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            whileHover={{ y: -6 }}
            className="glass-strong rounded-2xl p-6 electric-border group"
          >
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-electric/10 mb-5 group-hover:bg-electric/20 transition">
              <g.icon className="h-5 w-5 text-electric" />
            </div>
            <h3 className="font-display font-semibold mb-4">{g.title}</h3>
            <ul className="space-y-2">
              {g.skills.map((s) => (
                <li key={s} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="h-1 w-1 rounded-full bg-electric" />
                  {s}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
