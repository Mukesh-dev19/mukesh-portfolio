import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { Nav } from "@/components/portfolio/Nav";
import { Hero } from "@/components/portfolio/Hero";
import { ScrollProgress } from "@/components/portfolio/ScrollProgress";
import { Loader } from "@/components/portfolio/Loader";

const About = lazy(() => import("@/components/portfolio/About").then(m => ({ default: m.About })));
const Education = lazy(() => import("@/components/portfolio/Education").then(m => ({ default: m.Education })));
const Skills = lazy(() => import("@/components/portfolio/Skills").then(m => ({ default: m.Skills })));
const Projects = lazy(() => import("@/components/portfolio/Projects").then(m => ({ default: m.Projects })));
const Achievements = lazy(() => import("@/components/portfolio/Achievements").then(m => ({ default: m.Achievements })));
const Gate = lazy(() => import("@/components/portfolio/Gate").then(m => ({ default: m.Gate })));
const Vision = lazy(() => import("@/components/portfolio/Vision").then(m => ({ default: m.Vision })));
const Contact = lazy(() => import("@/components/portfolio/Contact").then(m => ({ default: m.Contact })));
const Footer = lazy(() => import("@/components/portfolio/Footer").then(m => ({ default: m.Footer })));
const MouseGlow = lazy(() => import("@/components/portfolio/MouseGlow").then(m => ({ default: m.MouseGlow })));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mukesh B — Electrical & Electronics Engineer | IoT & EV" },
      { name: "description", content: "Portfolio of Mukesh B, EEE student at Anna University. Power Systems, IoT, Electric Vehicles, Renewable Energy & GATE EE 2029." },
      { property: "og:title", content: "Mukesh B — Electrical & Electronics Engineer" },
      { property: "og:description", content: "Future power systems engineer building IoT, EV & smart energy projects from Chennai, India." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative overflow-x-hidden">
      <Loader />
      <ScrollProgress />
      <Suspense fallback={null}><MouseGlow /></Suspense>
      <Nav />
      <Hero />
      <Suspense fallback={<div className="h-32" />}>
        <About />
        <Education />
        <Skills />
        <Projects />
        <Achievements />
        <Gate />
        <Vision />
        <Contact />
        <Footer />
      </Suspense>
    </main>
  );
}
